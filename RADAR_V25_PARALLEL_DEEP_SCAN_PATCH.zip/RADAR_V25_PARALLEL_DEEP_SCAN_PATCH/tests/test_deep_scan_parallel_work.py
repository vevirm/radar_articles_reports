import json
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

from scripts.deep_read_works import identity_hash, record_key, source_hash

ROOT = Path(__file__).resolve().parents[1]


def make_row(i: int):
    return {
        "title": f"Example European research work {i}",
        "authors": "A. Researcher",
        "source": "Example Journal",
        "date": f"2026-08-{i:02d}",
        "first_seen": f"2026-08-{i:02d}T00:00:00Z",
        "link": f"https://example.test/work-{i}",
        "type": "peer-reviewed article",
        "summary": "Automatic scanner interpretation with enough provisional context.",
        "relevance_note": "Automatic relevance claim.",
    }


def keep_result(r, package_id: str):
    return {
        "record_key": record_key(r),
        "source_hash": source_hash(r),
        "identity_hash": identity_hash(r),
        "verification": {
            "identity_verified": True,
            "evidence_depth": "full_text_or_substantive_primary",
            "retrieval_attempts": [{"step": "supplied_url", "outcome": "success", "note": "Matching substantive publisher source was recovered."}],
            "recovered_sources": [{"kind": "publisher_full_text", "url": r["link"], "title": r["title"], "evidence_used": True}],
            "verification_note": "Verified carefully against the recovered substantive work.",
        },
        "admission": {"decision": "keep", "target_strand": "A", "reason_code": "A_SUBSTANTIVE_EU_RI", "reason": "The recovered work directly concerns substantive European research and innovation."},
        "metadata_correction": {"fields": {}, "unset": [], "reason": ""},
        "duplicate": {"status": "unique", "duplicate_of": "", "reason": ""},
        "reader_title": "Verified European research work",
        "reader_what": "Verified evidence establishes the work's central research finding.",
        "reader_why": "",
        "reader_more": "The full source was checked against the scanner record. The interpretation reflects the recovered work.",
        "deep_analysis": {
            "work_kind": "empirical study", "research_question": "Question", "main_finding": "Finding",
            "method_or_basis": "Full text", "qualification": "Bounded finding",
            "radar_relevance": "Substantive European R&I relevance", "why_supported": False, "confidence": "high",
        },
    }


def defer_result(r):
    steps = ["supplied_url", "doi", "exact_title", "title_author_year", "official_publisher_or_repository", "broader_identity_search"]
    notes = {
        "supplied_url": "Publisher landing page confirms identity but blocks substantive article text.",
        "doi": "DOI resolver confirms the same title and bibliographic identity but no accessible text.",
        "exact_title": "Exact-title search confirms the publication but yields no substantive accessible copy.",
        "title_author_year": "Title, author and year search confirms identity but no substantive evidence copy.",
        "official_publisher_or_repository": "Publisher and repository searches found citation metadata but no accessible substantive copy.",
        "broader_identity_search": "Broader identifier and author searches found no further legitimate substantive source.",
    }
    return {
        "record_key": record_key(r), "source_hash": source_hash(r), "identity_hash": identity_hash(r),
        "verification": {
            "identity_verified": True, "evidence_depth": "identity_only_after_recovery",
            "retrieval_attempts": [{"step": s, "outcome": "success" if s in {"supplied_url", "doi"} else "not_found", "note": notes[s]} for s in steps],
            "recovered_sources": [{"kind": "publisher_citation", "url": r["link"], "title": r["title"], "evidence_used": True}],
            "verification_note": "Identity is verified, but substantive evidence remains inaccessible after the full recovery ladder.",
        },
        "admission": {"decision": "defer", "target_strand": "A", "reason_code": "EVIDENCE_ACCESS_LIMITED", "reason": "Identity is confirmed, but substantive content cannot be judged without inventing evidence."},
        "metadata_correction": {"fields": {}, "unset": [], "reason": ""},
        "duplicate": {"status": "unique", "duplicate_of": "", "reason": ""},
        "reader_title": "", "reader_what": "", "reader_why": "", "reader_more": "",
        "deep_analysis": {"work_kind": "", "research_question": "", "main_finding": "", "method_or_basis": "", "qualification": "", "radar_relevance": "", "why_supported": False, "confidence": "low"},
    }


class ParallelDeepScanTests(unittest.TestCase):
    def test_two_worker_packages_are_disjoint_and_fifo_assigned(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            rows = [make_row(i) for i in range(1, 7)]
            corpus = root / "radar.json"
            sidecar = root / "reader_text.json"
            state = root / "deep_scan_work_state.json"
            status = root / "DEEP_SCAN_STATUS.md"
            corpus.write_text(json.dumps({"strand_a": rows, "strand_b": [], "strand_c": []}), encoding="utf-8")
            sidecar.write_text(json.dumps({"version": 3, "records": {}}), encoding="utf-8")

            lane_keys = {}
            for lane in ("A", "B"):
                out = root / f"out-{lane}"
                subprocess.run([
                    sys.executable, str(ROOT / "scripts/prepare_deep_scan_package.py"),
                    "--corpus", str(corpus), "--sidecar", str(sidecar), "--output-dir", str(out),
                    "--lane", lane, "--lane-size", "2", "--batch-size", "2", "--no-fetch",
                    "--work-state", str(state), "--status-file", str(status), "--write-work-state",
                ], cwd=ROOT, check=True)
                with zipfile.ZipFile(out / "deep_scan_package.zip") as zf:
                    batch_name = next(n for n in zf.namelist() if n.endswith("batch_001.json"))
                    batch = json.loads(zf.read(batch_name))
                    lane_keys[lane] = [j["record_key"] for j in batch["jobs"]]

            expected = [record_key(r) for r in rows]
            self.assertEqual(lane_keys["A"], expected[:2])
            self.assertEqual(lane_keys["B"], expected[2:4])
            self.assertTrue(set(lane_keys["A"]).isdisjoint(lane_keys["B"]))
            saved = json.loads(state.read_text())
            self.assertEqual(saved["lanes"]["A"]["assigned"], expected[:2])
            self.assertEqual(saved["lanes"]["B"]["assigned"], expected[2:4])
            self.assertIn("Worker A", status.read_text())

    def test_reserved_worker_b_can_import_while_older_worker_a_record_is_pending(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            first, second = make_row(1), make_row(2)
            corpus = root / "radar.json"
            sidecar = root / "reader_text.json"
            inbox = root / "deep_scan_inbox"; inbox.mkdir()
            state_path = root / "deep_scan_work_state.json"
            corpus.write_text(json.dumps({"strand_a": [first, second], "strand_b": [], "strand_c": []}), encoding="utf-8")
            sidecar.write_text(json.dumps({"version": 3, "records": {}}), encoding="utf-8")
            key1, key2 = record_key(first), record_key(second)
            state = {
                "version": 1, "profile": "radar-deep-scan-work-state-v1", "updated_at": None,
                "lanes": {
                    "A": {"target_size": 1, "assigned": [key1], "current_package_id": "pkg-a", "package_history": ["pkg-a"]},
                    "B": {"target_size": 1, "assigned": [key2], "current_package_id": "pkg-b", "package_history": ["pkg-b"]},
                },
                "records": {
                    key1: {"status": "assigned", "lane": "A", "last_package_id": "pkg-a"},
                    key2: {"status": "assigned", "lane": "B", "last_package_id": "pkg-b"},
                },
                "packages": {
                    "pkg-a": {"lane": "A", "created_at": "x", "record_keys": [key1]},
                    "pkg-b": {"lane": "B", "created_at": "x", "record_keys": [key2]},
                },
            }
            state_path.write_text(json.dumps(state), encoding="utf-8")
            result = {"format": "radar-deep-scan-results-v2", "package_id": "pkg-b", "results": [keep_result(second, "pkg-b")]}
            (inbox / "deep_scan_results.json").write_text(json.dumps(result), encoding="utf-8")
            subprocess.run([
                sys.executable, str(ROOT / "scripts/import_deep_scan_results.py"),
                "--corpus", str(corpus), "--sidecar", str(sidecar), "--inbox", str(inbox), "--work-state", str(state_path),
            ], cwd=ROOT, check=True)
            saved = json.loads(sidecar.read_text())
            self.assertNotIn(key1, saved["records"])
            self.assertEqual(saved["records"][key2]["profile"], "deep-reader-v2-authoritative")
            state2 = json.loads(state_path.read_text())
            self.assertEqual(state2["records"][key2]["status"], "verified")

    def test_defer_after_full_recovery_does_not_block_next_record_in_reserved_package(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            hard, next_row = make_row(1), make_row(2)
            corpus = root / "radar.json"
            sidecar = root / "reader_text.json"
            inbox = root / "deep_scan_inbox"; inbox.mkdir()
            state_path = root / "deep_scan_work_state.json"
            corpus.write_text(json.dumps({"strand_a": [hard, next_row], "strand_b": [], "strand_c": []}), encoding="utf-8")
            sidecar.write_text(json.dumps({"version": 3, "records": {}}), encoding="utf-8")
            keys = [record_key(hard), record_key(next_row)]
            state = {
                "version": 1, "profile": "radar-deep-scan-work-state-v1", "updated_at": None,
                "lanes": {"A": {"target_size": 2, "assigned": keys, "current_package_id": "pkg-a", "package_history": ["pkg-a"]}, "B": {"target_size": 2, "assigned": [], "current_package_id": "", "package_history": []}},
                "records": {k: {"status": "assigned", "lane": "A", "last_package_id": "pkg-a"} for k in keys},
                "packages": {"pkg-a": {"lane": "A", "created_at": "x", "record_keys": keys}},
            }
            state_path.write_text(json.dumps(state), encoding="utf-8")
            result = {"format": "radar-deep-scan-results-v2", "package_id": "pkg-a", "results": [defer_result(hard), keep_result(next_row, "pkg-a")]}
            (inbox / "deep_scan_results.json").write_text(json.dumps(result), encoding="utf-8")
            subprocess.run([
                sys.executable, str(ROOT / "scripts/import_deep_scan_results.py"),
                "--corpus", str(corpus), "--sidecar", str(sidecar), "--inbox", str(inbox), "--work-state", str(state_path),
            ], cwd=ROOT, check=True)
            saved = json.loads(sidecar.read_text())
            self.assertNotIn(keys[0], saved["records"])
            self.assertIn(keys[1], saved["records"])
            state2 = json.loads(state_path.read_text())
            self.assertEqual(state2["records"][keys[0]]["status"], "deferred")
            self.assertEqual(state2["records"][keys[1]]["status"], "verified")


if __name__ == "__main__":
    unittest.main()
