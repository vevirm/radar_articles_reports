# Deep Scan V2 — persistent parallel workers

This is a coordination extension to V25, not a change to the Radar admission or reasoning model.

## Why it exists

The original V25 Deep Scan importer was deliberately strict FIFO and the workflow exposed only the next 12 works. That is safe, but it creates too many manual GitHub round trips and makes it easy for two LLM chats to accidentally research the same records.

## Persistent queue model

GitHub now keeps a coordination ledger in `deep_scan_work_state.json` and a human-readable summary in `DEEP_SCAN_STATUS.md`.

- **Worker A** reserves the oldest unassigned pending records.
- **Worker B** reserves the next-oldest unassigned pending records.
- Default lane size is **36 each** (72 reserved works total), internally split into 12-record JSON batches for readability.
- The two lanes never overlap.
- Assignment is FIFO, so newly discovered records cannot jump ahead of the backlog.
- Completion may happen in either lane first. This is safe because each returned result is validated against the exact package reservation stored in GitHub.
- A result may be a carefully completed prefix. Remaining records stay assigned and appear in the refreshed package for that worker.

`reader_text.json` remains the authoritative record of completed V2 verification. The coordination ledger does not itself KEEP, DROP, reclassify, or alter reasoning.

## Access-limited works

A work can exist and have verified bibliographic identity while its substantive content remains unavailable even after the required six-step recovery ladder. That is different from `drop_unverifiable`.

For this case the parallel package permits `admission.decision = "defer"` with reason code `EVIDENCE_ACCESS_LIMITED`.

A defer:

- requires identity verification and all six documented recovery steps;
- must not contain invented reader interpretation or metadata corrections;
- does **not** create an authoritative admission decision;
- leaves the Radar record provisional;
- moves the work to the audited deferred-recovery list so it does not block dozens of later records.

## Normal operator flow

1. Run **Actions → Deep Scan V2 — Prepare Parallel Worker Packages** once after installing this patch.
2. Download **deep-scan-worker-A** and give its `deep_scan_package.zip` to one browsing-capable LLM.
3. Download **deep-scan-worker-B** and give its `deep_scan_package.zip` to another browsing-capable LLM.
4. Each LLM follows `START_HERE.txt` / `INSTRUCTIONS.md` and returns `deep_scan_results.json`. Partial prefixes are valid.
5. Upload each returned JSON to `deep_scan_inbox` and commit to `main`.
6. **Deep Scan V2 — Import Returned Results** validates/imports it, rebuilds active outputs, updates the persistent ledger, and publishes refreshed Worker A and Worker B artifacts.
7. A fresh LLM chat simply receives the latest artifact for its worker. No previous chat history is required.

## Preserved V25 safety properties

- Raw evidence in `radar.json` is never deleted by Deep Scan import.
- Admission/corrections become authoritative only after importer validation.
- Active outputs and downstream reasoning rebuild from the surviving active corpus.
- The existing raw-evidence immutability and active-corpus integrity checks remain in the import workflow.
- Legacy/unreserved V2 packages still use the original strict global FIFO fallback, so an already-issued package can be finished safely during the transition.
