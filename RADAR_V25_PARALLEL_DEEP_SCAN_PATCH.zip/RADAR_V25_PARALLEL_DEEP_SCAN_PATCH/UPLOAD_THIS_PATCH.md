# Upload this patch to the repository root

Upload the files/folders in this ZIP preserving their paths and commit directly to `main`.

Then run:

**Actions → Deep Scan V2 — Prepare Parallel Worker Packages → Run workflow**

Use the default lane size of 36 unless there is a specific reason to change it.

After the workflow is green, its Summary contains two artifacts:

- `deep-scan-worker-A`
- `deep-scan-worker-B`

Give one artifact's inner `deep_scan_package.zip` to each browsing-capable LLM. Returned result files go to `deep_scan_inbox` exactly as before.
