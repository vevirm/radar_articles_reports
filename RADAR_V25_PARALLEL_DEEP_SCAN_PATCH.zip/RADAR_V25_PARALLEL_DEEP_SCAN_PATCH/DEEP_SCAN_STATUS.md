# Deep Scan V2 work status

The persistent parallel-worker ledger is installed. GitHub regenerates this file when worker packages are prepared or results are imported.

- Worker A and Worker B are non-overlapping FIFO-assigned lanes.
- `reader_text.json` remains the authoritative record of completed Deep Scan V2 verification.
- `deep_scan_work_state.json` is coordination/audit state only; it does not change Radar admission or reasoning by itself.
