# ONE INSTALL ONLY — EDHEC Deep Scan, A=85 and B=85

**You have not installed previous packages. Use ONLY this ZIP.** It supersedes the earlier EDHEC ZIPs and contains the full 60-page PDF, source-level Deep Scan, admission sidecars and installer.

## Requested editorial scores
- **A: 85/100, manual cross-strand relevance score.** A remains a high-priority *methodological cross-reference*, **not** a standalone Strand A geopolitical/R&I event or independent A admission. No extra raw A row is created.
- **B: 85/100, manual source-merit override.** B is KEEP. One source is recorded, not two.
- **Underlying formula: 63/100**, retained as an independently calculated baseline. Neither 85 is described as rules-calculated.

Both strand-specific editorial numbers are present in the source and reader metadata. The existing UI scorer displays a **single source-merit 85** for the EDHEC source where shown; **this package does not add a separate Strand A ranking UI**. If you need the report to appear as an independent admitted Strand A entry, that would require changing the A admission rule, which this surgical patch does not do.

## Install — fresh repository (no earlier patch needed)
1. Extract this ZIP to a temporary folder **outside** the radar repository.
2. Run `python apply_edhec_deep_patch.py /path/to/radar_articles_reports-main` (read-only preflight).
3. Run `python apply_edhec_deep_patch.py /path/to/radar_articles_reports-main --apply` (backups, 1 EDHEC record, reader and admission sidecars, PDF and rebuild).
4. Review/commit modified repository files. The installer refuses mismatched source hashes, duplicates, incompatible source_merit.js versions, or an unexpected earlier reader interpretation.

The scanner's ordinary FIFO Deep Scan importer is **not** claimed to have run: this is an explicitly auditable manual source admission. The existing Siemens paper is preserved. The downstream rebuild has **not** been fully validated end-to-end.
