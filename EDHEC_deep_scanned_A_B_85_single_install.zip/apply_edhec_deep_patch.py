#!/usr/bin/env python3
"""Install one documented, user-supplied Deep Scan record, without FIFO importer bypass claims.
Usage: python apply_edhec_deep_patch.py /path/to/radar_articles_reports-main [--apply]
Default is read-only preflight. --apply installs with backups and rebuilds active products.
"""
import argparse,copy,hashlib,json,os,pathlib,sys,tempfile,subprocess,shutil
P=pathlib.Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('repo',type=pathlib.Path);ap.add_argument('--apply',action='store_true');args=ap.parse_args()
root=args.repo.resolve(); patch=json.loads((P/'patch.json').read_text()); key=patch['key']; pdf=P/'source_EDHEC_2026.pdf'
if hashlib.sha256(pdf.read_bytes()).hexdigest()!=patch['pdf_sha256']:sys.exit('ERROR source PDF hash mismatch')
paths=[root/f for f in ('radar.json','reader_text.json','admission_state.json')]
if not all(f.is_file() for f in paths):sys.exit('ERROR not at repository root (missing sidecars)')
sys.path.insert(0,str(root))
from scripts.deep_read_works import record_key,source_hash,identity_hash
from scripts.active_corpus import validate_sidecars,load_corrections
corpus,reader,admission=[json.loads(p.read_text()) for p in paths]
existing=[(s,r) for s in ('strand_a','strand_b','strand_c','frontier_evidence') for r in corpus.get(s,[]) if isinstance(r,dict) and (record_key(r)==key or 'Gen AI for Foresight, Innovation & Strategy' in str(r.get('title','')))]
if any(record_key(r)!=key for _,r in existing):sys.exit('ERROR possible existing EDHEC title with another record key; manual deduplication needed')
if existing and len(existing)!=1:sys.exit('ERROR EDHEC source duplicated across raw strands')
if existing and existing[0][0]!='strand_b':sys.exit('ERROR EDHEC exists in another strand; inspect before installing')
if key in reader.get('records',{}) and reader['records'][key].get('deep_scan_package_id')!='manual-edhec-pdf-20261102':sys.exit('ERROR existing independent verified reader interpretation; refusing overwrite')
if key in admission.get('records',{}) and admission['records'][key].get('deep_scan_package_id')!='manual-edhec-pdf-20261102':sys.exit('ERROR existing independent admission; refusing overwrite')
siemens=[r for r in corpus.get('strand_b',[]) if '10.1016/j.futures.2026.103883' in r.get('link','')]
if len(siemens)!=1:sys.exit('ERROR expected exactly one pre-existing Siemens study; review duplicates first')
row=copy.deepcopy(existing[0][1] if existing else patch['row'])
# Explicit, disclosed user-requested source-specific override; preserve baseline metadata.
for field in ('type','source_merit_manual_override','source_merit_manual_override_reason','source_merit_calculated_baseline','cross_strand_manual_scores','cross_strand_manual_score_provenance'):
 row[field]=patch['row'][field]
if existing and row.get('primary_document_sha256')!=patch['pdf_sha256']:sys.exit('ERROR existing record is not exact same manually verified source')
entry=copy.deepcopy(patch['reader']);entry['source_hash']=source_hash(row);entry['identity_hash']=identity_hash(row)
if not existing:corpus.setdefault('strand_b',[]).append(row)
reader.setdefault('records',{})[key]=entry
admission.setdefault('records',{})[key]=patch['admission']
errors=validate_sidecars(corpus,admission,load_corrections(root/'record_corrections.json'),reader)
if errors:sys.exit('ERROR sidecar validation: '+repr(errors[:3]))
print('PREFLIGHT PASS: 1 EDHEC source, Strand B KEEP, A cross-reference, manual A=85/100 and B=85/100 (calculated source baseline 63/100), Siemens preserved.')
print('Existing EDHEC source:',bool(existing),'Rebuild will run:',args.apply)
# Ensure the site's existing display scorer recognizes just this source's disclosed manual override.
merit_path=root/'source_merit.js'
if not merit_path.is_file():sys.exit('ERROR missing source_merit.js')
merit_text=merit_path.read_text(encoding='utf-8')
anchor='    const a=authority(x),r=relevance(x),e=evidence(x),ap=authorPoints(x),score=Math.max(0,Math.min(100,a.points+r.points+e.points+ap)),b=band(score);'
replacement='''    const a=authority(x),r=relevance(x),e=evidence(x),ap=authorPoints(x);
    const baseline=Math.max(0,Math.min(100,a.points+r.points+e.points+ap));
    // User-directed, auditable, one-record editorial override; not general authority scoring.
    const isEdhec=String(x?.id||'')==='edhec-genai-foresight-innovation-strategy-2026-10-20';
    const manual=isEdhec && Number(x?.source_merit_manual_override)===85;
    const score=manual?85:baseline,b=band(score);'''
if replacement not in merit_text and merit_text.count(anchor)!=1:sys.exit('ERROR unexpected source_merit.js version; refusing to edit scorer')
print('MERIT CHECK PASS: single-source 85/100 manual override with A/B score metadata; calculated 63/100 preserved in record.')
if not args.apply:sys.exit(0)
backup=root/'backups'/'edhec-manual-deep-20261102';backup.mkdir(parents=True,exist_ok=True)
for path in paths+[merit_path]:
 b=backup/path.name
 if not b.exists():shutil.copy2(path,b)
if replacement not in merit_text:
 merit_path.write_text(merit_text.replace(anchor,replacement),encoding='utf-8')
for path,doc in zip(paths,(corpus,reader,admission)):
 fd,tmp=tempfile.mkstemp(prefix='.edhec-',dir=path.parent)
 with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(doc,f,ensure_ascii=False,indent=2);f.write('\n')
 os.replace(tmp,path)
source_dir=root/'source_documents';source_dir.mkdir(exist_ok=True)
source=source_dir/'EDHEC_GenAI_Foresight_2026-10-20.pdf'
if source.exists() and hashlib.sha256(source.read_bytes()).hexdigest()!=patch['pdf_sha256']:sys.exit('ERROR destination source PDF differs')
if not source.exists():shutil.copy2(pdf,source)
print('Installed with backups. Rebuilding active corpus from existing project rules...')
p=subprocess.run([sys.executable,str(root/'scripts/rebuild_active_radar.py')],cwd=root)
if p.returncode:sys.exit('ERROR rebuild failed; backups at '+str(backup))
print('SUCCESS: one verified B record with high A cross-reference; PDF retained at '+str(source.relative_to(root)))
