# ONE-TIME Full Corpus Revalidation

Completed: `2026-09-11T00:36Z`

This was a corpus-only retrospective revalidation. It did **not** run discovery and did **not** rebuild shocks, risks, opportunities, trends, phenomena, or other higher-order reasoning.

## Diagnostics

- A kept: **352**
- A removed: **114**
- A reclassified to B: **1**
- B kept: **68**
- B removed: **5**
- B reclassified to A: **0**
- C kept/retained: **13**
- C removed: **42**
- C moved to archive: **0**
- C reactivated: **4**
- Duplicates removed: **6**
- Final A/B/C totals: **352 / 69 / 13**
- C archive retained: **0**

The 8:1:3 values were treated only as soft mix/share metadata. They were not used as caps, floors, quotas, rescue targets, or reasons to reject valid evidence.

## Audit trail

The JSON report contains one decision record for every active or historically accepted A/B/C row, including the reason, target strand/collection, gate snapshot where applicable, and duplicate winner where applicable.
