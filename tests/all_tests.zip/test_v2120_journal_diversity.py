import importlib.util
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_scanner():
    spec = importlib.util.spec_from_file_location("scan_radar_v2120", ROOT / "scripts" / "scan_radar.py")
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


class JournalDiversityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scan = load_scanner()
        cls.cfg = json.loads((ROOT / "radar_config.json").read_text(encoding="utf-8"))
        cls.radar = json.loads((ROOT / "radar.json").read_text(encoding="utf-8"))

    def test_priority_tasks_interleave_journals(self):
        tasks = self.scan.diversified_priority_journal_tasks(
            self.cfg["crossref_priority_journals"],
            self.cfg["crossref_priority_journal_queries"],
        )
        first = tasks[: min(16, len(tasks))]
        self.assertGreaterEqual(len({journal for journal, _query in first}), min(8, len(first)))

    def test_underrepresented_journal_lane_targets_sparse_venues(self):
        journals = self.cfg["crossref_priority_journals"]
        counts = self.scan.journal_representation_counts(journals, self.radar)
        bank = self.scan.underrepresented_journal_bank(
            journals, self.radar, self.cfg.get("journal_diversity_max_existing_items", 1)
        )
        self.assertTrue(bank)
        threshold = self.cfg.get("journal_diversity_max_existing_items", 1)
        self.assertTrue(all(counts[journal] <= threshold for journal in bank))

    def test_diversity_changes_attention_not_admission(self):
        policy = self.cfg.get("journal_diversity_policy", "")
        self.assertIn("admission", policy.lower())
        self.assertIn("unchanged", policy.lower())

    def test_phenomena_headings_are_capitalized_at_render_boundary(self):
        html = (ROOT / "phenomena" / "index.html").read_text(encoding="utf-8")
        self.assertIn("const heading=v=>", html)
        self.assertGreaterEqual(html.count("heading(x.title)"), 2)


if __name__ == "__main__":
    unittest.main()
