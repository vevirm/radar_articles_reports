import datetime as dt
import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ReaderReformV220Tests(unittest.TestCase):
    def test_all_reader_pages_load_shared_reform_shell(self):
        pages = [
            "radar/index.html", "read/index.html", "frontier/index.html",
            "frontier/quick/index.html", "trends/index.html", "phenomena/index.html",
            "priorities/index.html", "shocks/index.html", "historical/index.html",
            "literature/index.html", "glossary/index.html", "stuff/index.html",
            "briefing/index.html",
        ]
        for name in pages:
            html = (ROOT / name).read_text(encoding="utf-8")
            self.assertIn("reform.css?v=1.0", html, name)
            self.assertIn("site-shell.js?v=1.0", html, name)

    def test_navigation_contract_starts_with_read_at_least_this(self):
        shell = (ROOT / "site-shell.js").read_text(encoding="utf-8")
        read_i = shell.index("['read/'")
        radar_i = shell.index("['radar/'")
        self.assertLess(read_i, radar_i)
        self.assertIn("site-start-here", shell)
        css = (ROOT / "reform.css").read_text(encoding="utf-8")
        self.assertIn(".site-nav a.site-start-here", css)
        self.assertIn("background:var(--r-red)!important", css)

    def test_type_floor_and_mobile_matrix_contract(self):
        css = (ROOT / "reform.css").read_text(encoding="utf-8")
        self.assertIn("--r-small:.875rem", css)  # 14px at the 16px root
        self.assertIn(".matrix>.corner,.matrix>.col-head,.matrix>.col{display:none!important}", css)
        self.assertIn('content:"More control, stronger"', css)
        self.assertIn('content:"Less control, weaker"', css)
        frontier = (ROOT / "frontier" / "frontier.js").read_text(encoding="utf-8")
        self.assertNotIn("Matrix cell:", frontier)

    def test_topic_vocabulary_is_handwritten_sized_and_source_weighted(self):
        vocab = json.loads((ROOT / "topic_vocabulary.json").read_text(encoding="utf-8"))
        self.assertEqual(len(vocab), 75)
        self.assertTrue(all(x.get("label") and x.get("patterns") for x in vocab))
        cloud = (ROOT / "topic-cloud.js").read_text(encoding="utf-8")
        self.assertIn("sourceCount=sources.size", cloud)
        self.assertIn("sourceCount>=5&&t.recentShare>.5", cloud)
        self.assertIn("slice(0,6)", cloud)
        self.assertNotIn("x.source].join", cloud)

    def test_current_corpus_keeps_dense_topic_map(self):
        data = json.loads((ROOT / "radar.json").read_text(encoding="utf-8"))
        vocab = json.loads((ROOT / "topic_vocabulary.json").read_text(encoding="utf-8"))
        records = data.get("strand_a", []) + data.get("strand_b", []) + data.get("strand_c", [])
        active = 0
        for topic in vocab:
            sources = set()
            for item in records:
                text = " " + re.sub(
                    r"\s+", " ",
                    " ".join(str(item.get(k) or "") for k in (
                        "title", "headline", "summary", "core_message",
                        "relevance_note", "why_it_matters", "signal_note",
                    )).lower(),
                ).strip() + " "
                if any(str(p).lower() in text for p in topic["patterns"]):
                    source = str(item.get("source") or item.get("venue") or item.get("source_domain") or "").strip().lower()
                    if source:
                        sources.add(source)
            if len(sources) >= 2:
                active += 1
        self.assertGreaterEqual(active, 50)


if __name__ == "__main__":
    unittest.main()
