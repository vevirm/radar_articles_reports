import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class ReaderReformV230Tests(unittest.TestCase):
    def test_reader_pages_use_small_shared_shell_but_radar_is_isolated(self):
        pages = [
            "read/index.html", "frontier/index.html", "frontier/quick/index.html",
            "trends/index.html", "phenomena/index.html", "priorities/index.html",
            "shocks/index.html", "historical/index.html", "literature/index.html",
            "glossary/index.html", "stuff/index.html", "briefing/index.html",
        ]
        for name in pages:
            html=(ROOT/name).read_text(encoding="utf-8")
            self.assertIn("reform.css?v=23.0", html, name)
            self.assertIn("site-shell.js?v=23.0", html, name)
        radar=(ROOT/"radar/index.html").read_text(encoding="utf-8")
        self.assertIn("radar-calm.css?v=23.0", radar)
        self.assertNotIn("reform.css", radar)
        self.assertNotIn("site-shell.js", radar)

    def test_navigation_contract_is_three_clear_paths(self):
        home=(ROOT/"index.html").read_text(encoding="utf-8")
        self.assertIn("Read at least this", home)
        self.assertIn("Search the evidence", home)
        self.assertIn("Go deeper", home)
        shell=(ROOT/"site-shell.js").read_text(encoding="utf-8")
        self.assertIn("Briefing", shell)
        self.assertIn("Radar", shell)
        self.assertIn("Go deeper", shell)
        self.assertNotIn("site-menu", shell)

    def test_type_floor_and_mobile_matrix_contract(self):
        css=(ROOT/"reform.css").read_text(encoding="utf-8")
        self.assertIn("--r-small:.875rem", css)
        self.assertIn(".matrix>.corner,.calm-site .matrix>.col-head", css)
        self.assertIn("More control, stronger", css)
        self.assertIn("Less control, weaker", css)
        frontier=(ROOT/"frontier/frontier.js").read_text(encoding="utf-8")
        self.assertNotIn("Matrix cell:", frontier)

    def test_radar_application_code_keeps_original_contract(self):
        import hashlib
        html=(ROOT/"radar/index.html").read_text(encoding="utf-8")
        start=html.index("<script>\nconst PASSWORD_HASH")
        end=html.index("</script>",start)+len("</script>")
        app_js=html[start:end]
        self.assertEqual(hashlib.sha256(app_js.encode("utf-8")).hexdigest(),"a44b37781dc8cdeeab62985fdddc6856b8471408e8ccc652e683ca7723d751e7")
        for required in ['id="search"','id="newOnly"','id="recentOnly"','id="clearFilter"','id="itemsA"','id="itemsB"','id="itemsC"','id="moreA"','id="moreB"','id="moreC"']:
            self.assertIn(required,html)

    def test_topic_vocabulary_is_source_weighted_and_moving_is_capped(self):
        vocab=json.loads((ROOT/"topic_vocabulary.json").read_text(encoding="utf-8"))
        self.assertEqual(len(vocab),75)
        cloud=(ROOT/"topic-cloud.js").read_text(encoding="utf-8")
        self.assertIn("sourceCount=sources.size",cloud)
        self.assertIn("sourceCount>=5&&t.recentShare>.5",cloud)
        self.assertIn("slice(0,6)",cloud)

    def test_current_corpus_keeps_dense_topic_vocabulary_even_if_home_is_calm(self):
        data=json.loads((ROOT/"radar.json").read_text(encoding="utf-8"))
        vocab=json.loads((ROOT/"topic_vocabulary.json").read_text(encoding="utf-8"))
        records=data.get("strand_a",[])+data.get("strand_b",[])+data.get("strand_c",[])
        active=0
        for topic in vocab:
            sources=set()
            for item in records:
                text=" "+re.sub(r"\s+"," "," ".join(str(item.get(k) or "") for k in ("title","headline","summary","core_message","relevance_note","why_it_matters","signal_note")).lower()).strip()+" "
                if any(str(p).lower() in text for p in topic["patterns"]):
                    src=str(item.get("source") or item.get("venue") or item.get("source_domain") or "").strip().lower()
                    if src:sources.add(src)
            if len(sources)>=2:active+=1
        self.assertGreaterEqual(active,50)

    def test_home_count_includes_current_and_historical_corpora(self):
        html=(ROOT/"index.html").read_text(encoding="utf-8")
        js=(ROOT/"topic-cloud.js").read_text(encoding="utf-8")
        for token in ['id="currentCount"','id="historicalCount"','source organisations']:
            self.assertIn(token,html)
        self.assertIn("historical/historical.json",js)
        self.assertIn("allRecords=[...records,...historicalRecords]",js)

    def test_workflow_runs_regressions_before_scanner(self):
        workflow=(ROOT/".github/workflows/radar-scan.yml").read_text(encoding="utf-8")
        self.assertIn("Run scanner regression tests",workflow)
        self.assertIn("Run radar scan",workflow)
        self.assertLess(workflow.index("Run scanner regression tests"),workflow.index("Run radar scan"))

if __name__=="__main__": unittest.main()
