import json
import subprocess
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class PhenomenaAndStructureTests(unittest.TestCase):
    def run_node(self, source: str):
        proc = subprocess.run(
            ["node", "-e", source], cwd=ROOT, text=True, capture_output=True, check=True
        )
        return json.loads(proc.stdout)

    def test_phenomena_require_old_and_current_evidence(self):
        payload = self.run_node(
            """
const fs=require('fs');
const P=require('./phenomena/phenomena.js');
const d=JSON.parse(fs.readFileSync('radar.json','utf8'));
const h=JSON.parse(fs.readFileSync('historical/historical.json','utf8'));
const out=P.build(d,h);
console.log(JSON.stringify(out.map(x=>({
  id:x.id,current:x.currentCount,currentSources:x.currentSources,
  historical:x.historicalCount,historicalSources:x.historicalSources,
  oldDates:x.historicalEvidence.map(e=>String(e.date||'').slice(0,10)),
  newDates:x.currentEvidence.map(e=>String(e.date||'').slice(0,10))
}))));
"""
        )
        self.assertGreaterEqual(len(payload), 5)
        cutoff = json.loads((ROOT / "historical" / "historical.json").read_text(encoding="utf-8"))["cutoff_exclusive"]
        for item in payload:
            self.assertGreaterEqual(item["current"], 3, item["id"])
            self.assertGreaterEqual(item["currentSources"], 2, item["id"])
            self.assertGreaterEqual(item["historical"], 2, item["id"])
            self.assertGreaterEqual(item["historicalSources"], 2, item["id"])
            for date in item["oldDates"]:
                self.assertLess(date, cutoff, item["id"])
            for date in item["newDates"]:
                self.assertGreaterEqual(date, cutoff, item["id"])

    def test_old_evidence_alone_cannot_create_ongoing_phenomenon(self):
        result = self.run_node(
            """
const fs=require('fs');
const P=require('./phenomena/phenomena.js');
const h=JSON.parse(fs.readFileSync('historical/historical.json','utf8'));
console.log(JSON.stringify({count:P.build({strand_a:[],strand_c:[]},h).length}));
"""
        )
        self.assertEqual(result["count"], 0)

    def test_home_exposes_start_here_navigation_and_live_topic_map(self):
        html = (ROOT / "index.html").read_text(encoding="utf-8")
        for phrase in [
            "Research &amp; Innovation × Geopolitics Radar",
            "pieces of evidence in the library", "source organisations",
            "Read at least this", "Radar", "Matrix", "Trends",
            "Ongoing phenomena", "Risks &amp; opportunities", "External shocks",
            "Historical", "Sources", "Glossary", "Stuff",
            "Bigger = more independent sources. Red = mostly new.",
            "topic_vocabulary.json", "topic-cloud.js"
        ]:
            self.assertIn(phrase, html if phrase != "topic_vocabulary.json" else (ROOT / "topic-cloud.js").read_text(encoding="utf-8"))
        nav = html[html.index('<nav class="home-actions"'):html.index('</nav>')+6]
        self.assertLess(nav.index("Read at least this"), nav.index("Browse the Radar"))
        self.assertIn('class="start" href="read/"', nav)
        self.assertNotIn("OPEN THE MAIN RADAR", html)
        vocab = json.loads((ROOT / "topic_vocabulary.json").read_text(encoding="utf-8"))
        self.assertEqual(len(vocab), 75)

    def test_main_radar_starts_with_search_then_evidence(self):
        html = (ROOT / "radar" / "index.html").read_text(encoding="utf-8")
        search = html.index('id="search"')
        first_items = html.index('id="strand-a"')
        self.assertLess(search, first_items)
        self.assertIn("Established evidence", html)
        self.assertIn("Ways to look ahead", html)
        self.assertIn("Weak signals", html)
        self.assertNotIn('class="core-path"', html)
        self.assertNotIn('class="strand-jump"', html)


if __name__ == "__main__":
    unittest.main()
