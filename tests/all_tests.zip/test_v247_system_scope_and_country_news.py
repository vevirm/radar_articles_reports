"""Regression tests for the v24.7 semantic/source-discovery repair.

The mission is to observe European R&I as a strategic system. Internal European state-variable
changes are admissible even without geopolitical vocabulary; retrieval/source prestige never
substitutes for an R&I-system relationship.
"""
from pathlib import Path
import importlib.util
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCAN = ROOT / "scripts" / "scan_radar.py"
spec = importlib.util.spec_from_file_location("radar_v247_scope", SCAN)
S = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = S
spec.loader.exec_module(S)


class V247SystemScopeAndCountryNews(unittest.TestCase):
    def gate(self, title, abstract, *, kind="scholarly", tier=1):
        return S.gate_scope(title, abstract, "", tier, kind)

    def c_admitted(self, headline, desc, source, domain, link="https://example.test/item"):
        row = {
            "headline": headline,
            "_desc": desc,
            "source": source,
            "source_domain": domain,
            "link": link,
            "date": "2026-09-10",
            "_themes": list(S.themes_for(f"{headline}. {desc}")),
        }
        diagnostics = []
        out = S.anchor_news([row], [], diagnostics, allow_unanchored=True)
        return bool(out), diagnostics

    def test_internal_european_deep_tech_financing_gap_is_A(self):
        row = self.gate(
            "Deep-tech scale-up financing gap in Europe",
            "We benchmark venture and growth capital availability for European deep-tech firms "
            "against the United States and analyse implications for scale-up capacity.",
        )
        self.assertTrue(row["a_pass"], row)

    def test_doctoral_candidate_wellbeing_does_not_become_A(self):
        row = self.gate(
            "Mental health of doctoral candidates in European universities",
            "We survey doctoral candidates across ten European countries and analyse depression, "
            "stress and wellbeing.",
        )
        self.assertFalse(row["a_pass"], row)

    def test_incidental_innovation_performance_does_not_become_A(self):
        row = self.gate(
            "Green bond issuance and firm value: evidence from European listed companies",
            "Using panel data on European listed companies, we find innovation performance "
            "moderates the relationship between green bond issuance and firm value.",
        )
        self.assertFalse(row["a_pass"], row)

    def test_sectoral_innovation_ecosystem_does_not_become_A(self):
        row = self.gate(
            "Innovation ecosystems and wine cooperatives in Southern Europe",
            "This study analyses innovation ecosystems surrounding wine cooperatives in Spain, "
            "Italy and Portugal.",
        )
        self.assertFalse(row["a_pass"], row)

    def test_european_technology_standard_setting_capacity_is_A(self):
        row = self.gate(
            "European leadership in ISO/IEC artificial intelligence standards committees",
            "We map European participation and leadership in ISO/IEC AI technical committees and "
            "compare representation with the United States and China.",
        )
        self.assertTrue(row["a_pass"], row)

    def test_roadmapping_review_is_B(self):
        row = self.gate(
            "Technology roadmapping: a review of approaches",
            "This paper reviews technology roadmapping approaches, synthesises methodological "
            "designs and compares their strengths and limitations.",
        )
        self.assertTrue(row["b_pass"], row)

    def test_scenario_planning_and_firm_performance_is_not_B(self):
        row = self.gate(
            "Scenario planning and firm performance",
            "This paper studies whether using scenario planning improves firm performance.",
        )
        self.assertFalse(row["b_pass"], row)

    def test_recruiting_story_is_not_mistaken_for_job_ad(self):
        self.assertFalse(S.routine_signal_noise(
            "China is recruiting researchers from European universities through state-sponsored talent programmes",
            "The programme offers relocation grants and laboratory funding to researchers currently "
            "working at European universities.",
        ))

    def test_actual_job_ad_remains_noise(self):
        self.assertTrue(S.routine_signal_noise(
            "Postdoctoral researcher position in quantum technologies",
            "Applications are invited for a full-time postdoctoral position. Application deadline 30 September.",
        ))

    def test_workshop_word_does_not_poison_formal_policy_event(self):
        ok, diagnostics = self.c_admitted(
            "Council adopts position on European Research Area Act",
            "After a workshop with stakeholders, the Council adopted its position on the European "
            "Research Area Act, changing governance and research-career provisions ahead of negotiations.",
            "Reuters", "reuters.com",
        )
        self.assertTrue(ok, diagnostics)

    def test_configured_c_sources_are_elite_not_broad_national_media(self):
        names = {str(x.get("name")) for x in S.configured_c_news_sources()}
        self.assertIn("Reuters", names)
        self.assertIn("Politico Europe", names)
        self.assertIn("NATO", names)
        self.assertIn("OECD", names)
        self.assertNotIn("Yle News", names)
        self.assertNotIn("YouTube", names)

    def test_yle_google_finland_investment_is_context_not_public_C(self):
        ok, diagnostics = self.c_admitted(
            "Google announces €13bn additional investment in Finland",
            "Google announced an additional €13 billion investment in Finland to expand data centres "
            "and AI infrastructure, its largest investment in Europe.",
            "Yle News", "yle.fi", "https://yle.fi/a/74-20245301",
        )
        self.assertFalse(ok, diagnostics)
        self.assertTrue(any(d.get("reason") == "source_not_europe_trusted" for d in diagnostics), diagnostics)

    def test_dialogue_without_change_is_not_C(self):
        ok, diagnostics = self.c_admitted(
            "Commissioner leads dialogue on how to attract and retain research talent in Europe",
            "The Commissioner met stakeholders for a dialogue on how Europe can attract and retain "
            "research talent. Participants discussed ideas and future options.",
            "ERA Portal Austria", "era.gv.at",
        )
        self.assertFalse(ok, diagnostics)

    def test_eu_ai_data_centre_commitment_is_C(self):
        ok, diagnostics = self.c_admitted(
            "EU launches €30B push to build 7 massive AI data centers",
            "The programme launches seven AI data centres as new European compute capacity.",
            "Politico Europe", "politico.eu",
        )
        self.assertTrue(ok, diagnostics)

    def test_member_state_public_service_ai_factory_is_not_routine_C(self):
        ok, diagnostics = self.c_admitted(
            "Baltics' first AI factory to open in Estonia",
            "Estonia is opening the Baltic region's first AI factory to add computing capacity for research and companies.",
            "ERR News", "err.ee",
        )
        self.assertFalse(ok, diagnostics)

    def test_general_tech_outlet_is_not_routine_C(self):
        ok, diagnostics = self.c_admitted(
            "Mistral bags €3B to build Europe's sovereign AI champion",
            "The financing will expand European AI model and compute capability.",
            "The Register", "theregister.com",
        )
        self.assertFalse(ok, diagnostics)

    def test_broad_international_tv_news_is_not_routine_C(self):
        ok, diagnostics = self.c_admitted(
            "Europe looks to challenge US dominance in space sector with €10 billion plan",
            "Officials are considering a published €10 billion plan that could support future European space technology capacity.",
            "France 24", "france24.com",
        )
        self.assertFalse(ok, diagnostics)

    def test_think_tank_or_academic_commentary_is_not_routine_C(self):
        ok, diagnostics = self.c_admitted(
            "Europe’s strategic autonomy depends on open and secure science",
            "The analysis examines how open science, research security and European strategic autonomy interact across the research system.",
            "LSE European Politics and Policy", "blogs.lse.ac.uk",
        )
        self.assertFalse(ok, diagnostics)

    def test_trusted_nordic_quantum_funding_news_is_C(self):
        ok, diagnostics = self.c_admitted(
            "Funding Radar: G7 and Nordics jointly fund quantum research",
            "Nordic funders and G7 partners announced joint funding for quantum research collaboration and strategic technology projects.",
            "Science|Business", "sciencebusiness.net",
        )
        self.assertTrue(ok, diagnostics)

    def test_trusted_europe_route_still_rejects_unrelated_foreign_tech_news(self):
        ok, diagnostics = self.c_admitted(
            "IBM links cryogenic modules to scale fault-tolerant quantum computing",
            "IBM introduced cryogenic control modules for quantum computing in the United States.",
            "eeNews Europe", "eenewseurope.com",
        )
        self.assertFalse(ok, diagnostics)


    def test_scmp_is_not_a_strand_c_source_even_when_story_mentions_europe(self):
        ok, diagnostics = self.c_admitted(
            "China’s self-driving push gears up in Europe as Momenta and Pony.ai expand",
            "Chinese autonomous-driving companies are expanding operations in Europe and opening new European partnerships.",
            "South China Morning Post", "scmp.com", "https://www.scmp.com/example",
        )
        self.assertFalse(ok, diagnostics)
        self.assertTrue(any(d.get("reason") == "source_not_europe_trusted" for d in diagnostics), diagnostics)

    def test_nikkei_asia_is_not_a_strand_c_source(self):
        ok, diagnostics = self.c_admitted(
            "Asian chip group expands European research operations",
            "The company announced a new research and semiconductor development operation in Europe.",
            "Nikkei Asia", "asia.nikkei.com", "https://asia.nikkei.com/example",
        )
        self.assertFalse(ok, diagnostics)

    def test_reuters_direct_eu_development_remains_c(self):
        ok, diagnostics = self.c_admitted(
            "EU agrees new research-security screening rules for sensitive technologies",
            "European Union governments agreed new screening rules affecting research collaboration and dual-use technology projects.",
            "Reuters", "reuters.com", "https://www.reuters.com/world/europe/example",
        )
        self.assertTrue(ok, diagnostics)

    def test_configured_c_discovery_excludes_scmp_and_nikkei(self):
        domains = {str(x.get("domain")) for x in S.configured_c_news_sources()}
        self.assertNotIn("scmp.com", domains)
        self.assertNotIn("asia.nikkei.com", domains)
        self.assertIn("politico.eu", domains)
        self.assertIn("reuters.com", domains)

    def test_C_pre_novelty_cap_is_not_publication_cap(self):
        self.assertGreaterEqual(int(S.CONFIG.get("c_pre_novelty_candidate_cap", 0)), 20)
        self.assertLessEqual(int(S.CONFIG.get("c_min_new_per_successful_scan", 3)), 3)


if __name__ == "__main__":
    unittest.main()
